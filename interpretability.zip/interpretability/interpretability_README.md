# COCONUT Interpretability Experiments

**Research Direction**: "What Do Latent Tokens Learn for Visual Deception Detection?"

This directory contains scripts for interpretability experiments on COCONUT (Chain-of-Continuous-Thought) models trained for phishing detection.

## Overview

The experiments analyze what semantic information is encoded in latent tokens during visual phishing detection. Unlike Chain-of-Thought (CoT) where reasoning is explicit text, COCONUT uses continuous latent tokens - making interpretability crucial for understanding the model's decision process.

## Scripts

### 1. `attention_extraction.py`
Extract and visualize attention patterns between:
- Latent tokens ↔ Image patches
- Latent tokens ↔ Text tokens
- Cross-latent-token attention

```bash
python attention_extraction.py \
    --model_path saves/el_coconut_stage5_c2_merged \
    --image_path /path/to/screenshot.jpg \
    --output_dir ./attention_outputs
```

### 2. `comparative_analysis.py`
Compare attention patterns across model variants:
- COCONUT c2, c3, c4 (different numbers of latent tokens)
- CoT baseline

Includes CKA (Centered Kernel Alignment) similarity analysis.

```bash
python comparative_analysis.py \
    --base_path /data_shubho/local/users/shmallic/ed_fixed/LlamaFactory \
    --test_file testset_sharegpt_data_may23.json \
    --output_dir ./comparative_analysis
```

### 3. `probing_experiments.py`
Train linear probes to understand what information is encoded:
- **Layer-wise probing**: At which layer does phishing detection emerge?
- **Position-wise probing**: Does each latent token encode different aspects?
- **Task probes**: Phishing label, brand detection, attack type

```bash
python probing_experiments.py \
    --model_path saves/el_coconut_stage5_c2_merged \
    --test_file testset_sharegpt_data_may23.json \
    --image_base /path/to/images \
    --output_dir ./probing_results
```

## Trained Models

Available at `/data_shubho/local/users/shmallic/ed_fixed/LlamaFactory/saves/`:

| Model | Path | Latent Tokens | Notes |
|-------|------|---------------|-------|
| EL COCONUT | `el_coconut_stage5_c2_merged` | 2 | Full curriculum training |
| Ablation c3 | `coco_s5_c3_merged` | 3 | 3 tokens per step |
| Ablation c4 | `coco_s5_c4_merged` | 4 | 4 tokens per step |
| EL CoT | `el_cot_merged` | 0 | Text reasoning baseline |

## Key Research Questions

1. **What visual features do latent tokens attend to?**
   - Logos, forms, text, UI elements?
   - Does attention differ for malicious vs benign?

2. **Do latent tokens specialize?**
   - Does token 1 encode different information than token 2?
   - Is there a "reasoning progression" across tokens?

3. **Where does classification emerge?**
   - Early layers = visual features
   - Middle layers = semantic understanding
   - Late layers = decision

4. **COCONUT vs CoT representations**
   - How similar are hidden states? (CKA)
   - Does COCONUT develop unique features?

5. **Failure mode analysis**
   - When COCONUT fails but CoT succeeds (or vice versa)
   - What attention patterns distinguish these cases?

## Expected Outputs

- `attention_outputs/`: Attention heatmaps overlaid on images
- `comparative_analysis/`: Model comparison plots, CKA heatmaps
- `probing_results/`: Layer-wise accuracy curves, position heatmaps

## Paper Structure Suggestion

1. **Introduction**: COCONUT for visual security, need for interpretability
2. **Method**: Attention extraction, linear probing, CKA comparison
3. **RQ1**: Attention analysis - what regions are attended to
4. **RQ2**: Probing - what information is encoded
5. **RQ3**: Comparison - COCONUT vs CoT representations
6. **RQ4**: Failure modes and limitations
7. **Discussion**: Implications for deploying interpretable security models

## Dependencies

```bash
pip install torch transformers pillow matplotlib seaborn scikit-learn scipy tqdm
```

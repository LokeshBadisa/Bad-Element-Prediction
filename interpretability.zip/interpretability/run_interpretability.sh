#!/bin/bash
# Run COCONUT interpretability experiments on DLIS
# Usage: bash run_interpretability.sh

set -e

# Paths
BASE_PATH="/data_shubho/local/users/shmallic/ed_fixed/LlamaFactory"
TRAIN_MLLS="/data_shubho/local/users/shmallic/bep/train_MLLMs"
IMAGE_BASE="/data_shubho/local/users/shmallic/bep/openphish_crop_images"
OUTPUT_BASE="/data_shubho/local/users/shmallic/bep/interpretability_results"

# Test file
TEST_FILE="${TRAIN_MLLS}/testset_sharegpt_data_may23.json"

# Models
EL_COCONUT="${BASE_PATH}/saves/el_coconut_stage5_c2_merged"
ABLATION_C3="${BASE_PATH}/saves/coco_s5_c3_merged"
ABLATION_C4="${BASE_PATH}/saves/coco_s5_c4_merged"
EL_COT="${BASE_PATH}/saves/el_cot_merged"

# Create output directories
mkdir -p "${OUTPUT_BASE}/attention"
mkdir -p "${OUTPUT_BASE}/comparative"
mkdir -p "${OUTPUT_BASE}/probing_c2"
mkdir -p "${OUTPUT_BASE}/probing_c3"
mkdir -p "${OUTPUT_BASE}/probing_c4"

# Activate environment
source $(conda info --base)/etc/profile.d/conda.sh
conda activate llamafactory

cd "${TRAIN_MLLS}/inference"

echo "======================================"
echo "COCONUT Interpretability Experiments"
echo "======================================"

# 1. Single image attention extraction (for debugging/demos)
echo ""
echo "[1/4] Testing attention extraction on single image..."
# Find first image in test set
SAMPLE_IMAGE=$(python -c "import json; d=json.load(open('${TEST_FILE}')); print(d[0]['images'][-1])" 2>/dev/null || echo "")
if [ -n "$SAMPLE_IMAGE" ]; then
    python attention_extraction.py \
        --model_path "${EL_COCONUT}" \
        --image_path "${SAMPLE_IMAGE}" \
        --output_dir "${OUTPUT_BASE}/attention" \
        --device cuda
fi

# 2. Comparative analysis across models
echo ""
echo "[2/4] Running comparative analysis..."
python comparative_analysis.py \
    --base_path "${BASE_PATH}" \
    --test_file "${TEST_FILE}" \
    --image_base "${IMAGE_BASE}" \
    --output_dir "${OUTPUT_BASE}/comparative" \
    --limit 50 \
    --device cuda

# 3. Probing experiments for each model variant
echo ""
echo "[3/4] Running probing experiments..."

# EL COCONUT (c2)
echo "  - Probing EL COCONUT (c2)..."
python probing_experiments.py \
    --model_path "${EL_COCONUT}" \
    --test_file "${TEST_FILE}" \
    --image_base "${IMAGE_BASE}" \
    --output_dir "${OUTPUT_BASE}/probing_c2" \
    --limit 200 \
    --device cuda

# Ablation c3
echo "  - Probing Ablation c3..."
python probing_experiments.py \
    --model_path "${ABLATION_C3}" \
    --test_file "${TEST_FILE}" \
    --image_base "${IMAGE_BASE}" \
    --output_dir "${OUTPUT_BASE}/probing_c3" \
    --limit 200 \
    --device cuda

# Ablation c4
echo "  - Probing Ablation c4..."
python probing_experiments.py \
    --model_path "${ABLATION_C4}" \
    --test_file "${TEST_FILE}" \
    --image_base "${IMAGE_BASE}" \
    --output_dir "${OUTPUT_BASE}/probing_c4" \
    --limit 200 \
    --device cuda

# 4. Summary
echo ""
echo "[4/4] Generating summary..."
echo "======================================"
echo "Experiments complete!"
echo "Results saved to: ${OUTPUT_BASE}"
echo ""
echo "Directory structure:"
echo "  ${OUTPUT_BASE}/"
echo "  ├── attention/      - Single-image attention visualizations"
echo "  ├── comparative/    - Model comparison (CKA, accuracy)"  
echo "  ├── probing_c2/     - EL COCONUT probing results"
echo "  ├── probing_c3/     - Ablation c3 probing results"
echo "  └── probing_c4/     - Ablation c4 probing results"
echo "======================================"

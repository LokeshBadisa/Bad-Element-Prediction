"""
Attention Extraction for COCONUT Latent Token Interpretability

This script extracts and visualizes attention patterns between:
1. Latent tokens ↔ Image patches
2. Latent tokens ↔ Text tokens
3. Cross-latent-token attention

Usage:
    python attention_extraction.py \
        --model_path saves/coco_s5_c4_merged \
        --image_path /path/to/screenshot.jpg \
        --output_dir ./attention_outputs
"""

import os
import sys
import json
import torch
import argparse
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from PIL import Image
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from tqdm import tqdm

# Add transformers path if needed
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'ed', 'ED', 'transformers', 'src'))

from transformers import AutoProcessor
from transformers.models.auto import AutoModelForVision2Seq


@dataclass
class AttentionOutput:
    """Container for extracted attention data"""
    # Per-layer attention weights: List[Tensor of shape (batch, heads, seq, seq)]
    layer_attentions: List[torch.Tensor]
    # Token indices
    latent_token_indices: List[int]
    image_token_indices: List[int]
    text_token_indices: List[int]
    # Token strings for visualization
    tokens: List[str]
    # Image grid info for mapping back to patches
    image_grid_thw: Optional[torch.Tensor] = None


class AttentionExtractor:
    """Extract attention weights from COCONUT models"""
    
    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        dtype: torch.dtype = torch.bfloat16
    ):
        self.device = device
        self.dtype = dtype
        
        print(f"Loading model from {model_path}...")
        self.processor = AutoProcessor.from_pretrained(model_path)
        self.model = AutoModelForVision2Seq.from_pretrained(
            model_path,
            torch_dtype=dtype,
            device_map=device,
            trust_remote_code=True,
            attn_implementation="eager"  # Required for attention output
        )
        self.model.eval()
        
        # Get special token IDs
        self.latent_token_id = getattr(self.model.config, 'latent_id', None)
        self.start_latent_id = getattr(self.model.config, 'start_latent_id', None)
        self.end_latent_id = getattr(self.model.config, 'end_latent_id', None)
        self.image_token_id = self.model.config.image_token_id
        
        print(f"Latent token ID: {self.latent_token_id}")
        print(f"Image token ID: {self.image_token_id}")
    
    def prepare_input(
        self,
        image_path: str,
        prompt: str = "Analyze this webpage screenshot and classify it as benign or malicious."
    ) -> Dict:
        """Prepare model input from image and prompt"""
        image = Image.open(image_path).convert("RGB")
        
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": prompt}
                ]
            }
        ]
        
        inputs = self.processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt"
        )
        
        return {k: v.to(self.device) for k, v in inputs.items()}, image
    
    def extract_attention(
        self,
        image_path: str,
        prompt: str = "Analyze this webpage screenshot and classify it as benign or malicious.",
        max_new_tokens: int = 512
    ) -> Tuple[AttentionOutput, str]:
        """
        Extract attention weights during generation
        
        Returns:
            AttentionOutput with attention data
            Generated text response
        """
        inputs, image = self.prepare_input(image_path, prompt)
        input_ids = inputs["input_ids"]
        
        # Find token indices
        latent_indices = (input_ids[0] == self.latent_token_id).nonzero(as_tuple=True)[0].tolist()
        image_indices = (input_ids[0] == self.image_token_id).nonzero(as_tuple=True)[0].tolist()
        
        # All other tokens are text
        all_special = set(latent_indices + image_indices)
        text_indices = [i for i in range(input_ids.shape[1]) if i not in all_special]
        
        print(f"Found {len(latent_indices)} latent tokens")
        print(f"Found {len(image_indices)} image tokens")
        print(f"Found {len(text_indices)} text tokens")
        
        # Generate with attention output
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                output_attentions=True,
                return_dict_in_generate=True,
                do_sample=False
            )
        
        # Decode output
        generated_ids = outputs.sequences[0][input_ids.shape[1]:]
        generated_text = self.processor.decode(generated_ids, skip_special_tokens=True)
        
        # Extract attention weights
        # outputs.attentions is a tuple of (generation_step, layer, attention_tensor)
        attentions = outputs.attentions if hasattr(outputs, 'attentions') else None
        
        # Get tokens for visualization
        tokens = self.processor.tokenizer.convert_ids_to_tokens(input_ids[0].tolist())
        
        # Get image grid info if available
        image_grid_thw = inputs.get("image_grid_thw", None)
        
        attention_output = AttentionOutput(
            layer_attentions=attentions,
            latent_token_indices=latent_indices,
            image_token_indices=image_indices,
            text_token_indices=text_indices,
            tokens=tokens,
            image_grid_thw=image_grid_thw
        )
        
        return attention_output, generated_text
    
    def extract_hidden_states(
        self,
        image_path: str,
        prompt: str = "Analyze this webpage screenshot and classify it as benign or malicious."
    ) -> Dict[str, torch.Tensor]:
        """
        Extract hidden states at latent token positions for probing experiments
        
        Returns:
            Dict with hidden states per layer and per latent token
        """
        inputs, _ = self.prepare_input(image_path, prompt)
        input_ids = inputs["input_ids"]
        
        # Find latent token indices
        latent_indices = (input_ids[0] == self.latent_token_id).nonzero(as_tuple=True)[0].tolist()
        
        with torch.no_grad():
            # Forward pass with hidden states output
            outputs = self.model(
                **inputs,
                output_hidden_states=True,
                return_dict=True
            )
        
        hidden_states = outputs.hidden_states  # Tuple of (layer, batch, seq, hidden)
        
        # Extract hidden states at latent token positions
        latent_hidden_states = {}
        for layer_idx, layer_hidden in enumerate(hidden_states):
            latent_hidden_states[f"layer_{layer_idx}"] = {
                f"latent_{i}": layer_hidden[0, idx, :].cpu()
                for i, idx in enumerate(latent_indices)
            }
        
        return latent_hidden_states, latent_indices


class AttentionVisualizer:
    """Visualize attention patterns"""
    
    def __init__(self, output_dir: str = "./attention_outputs"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def plot_attention_heatmap(
        self,
        attention: torch.Tensor,
        x_labels: List[str],
        y_labels: List[str],
        title: str,
        save_name: str,
        figsize: Tuple[int, int] = (12, 8)
    ):
        """Plot attention as heatmap"""
        fig, ax = plt.subplots(figsize=figsize)
        
        # Average over heads if needed
        if attention.dim() > 2:
            attention = attention.mean(dim=0)  # Average over heads
        
        attention_np = attention.cpu().numpy()
        
        im = ax.imshow(attention_np, cmap='viridis', aspect='auto')
        
        ax.set_xticks(range(len(x_labels)))
        ax.set_yticks(range(len(y_labels)))
        ax.set_xticklabels(x_labels, rotation=90, fontsize=6)
        ax.set_yticklabels(y_labels, fontsize=6)
        
        ax.set_title(title)
        plt.colorbar(im, ax=ax)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, save_name), dpi=150, bbox_inches='tight')
        plt.close()
    
    def plot_latent_to_image_attention(
        self,
        attention_output: AttentionOutput,
        image: Image.Image,
        layer_idx: int = -1,
        save_name: str = "latent_to_image_attention.png"
    ):
        """
        Overlay attention from latent tokens onto original image
        
        Args:
            attention_output: AttentionOutput from extraction
            image: Original PIL Image
            layer_idx: Which layer's attention to visualize (-1 for last)
            save_name: Output filename
        """
        if attention_output.layer_attentions is None:
            print("No attention weights available")
            return
        
        # Get attention from specified layer
        # Shape: (batch, heads, seq_len, seq_len)
        layer_attn = attention_output.layer_attentions[layer_idx]
        
        # Extract attention from latent tokens to image tokens
        latent_indices = attention_output.latent_token_indices
        image_indices = attention_output.image_token_indices
        
        if len(latent_indices) == 0 or len(image_indices) == 0:
            print("No latent or image tokens found")
            return
        
        # Get attention scores: latent -> image
        # Average over heads
        attn_scores = layer_attn[0].mean(dim=0)  # (seq, seq)
        latent_to_image_attn = attn_scores[latent_indices][:, image_indices]  # (n_latent, n_image)
        
        # Create figure
        n_latent = len(latent_indices)
        fig, axes = plt.subplots(1, n_latent + 1, figsize=(4 * (n_latent + 1), 4))
        
        # Plot original image
        axes[0].imshow(image)
        axes[0].set_title("Original Image")
        axes[0].axis('off')
        
        # Plot attention overlay for each latent token
        img_array = np.array(image)
        img_h, img_w = img_array.shape[:2]
        
        # Compute patch grid size (assuming square patches)
        n_image_tokens = len(image_indices)
        grid_size = int(np.sqrt(n_image_tokens))
        
        for i, latent_idx in enumerate(range(n_latent)):
            ax = axes[i + 1]
            
            # Get attention for this latent token
            attn = latent_to_image_attn[latent_idx].cpu().numpy()
            
            # Reshape to grid
            if len(attn) == grid_size * grid_size:
                attn_grid = attn.reshape(grid_size, grid_size)
            else:
                # Pad or truncate
                attn_grid = np.zeros((grid_size, grid_size))
                attn_flat = attn.flatten()[:grid_size*grid_size]
                attn_grid.flat[:len(attn_flat)] = attn_flat
            
            # Resize to image dimensions
            from scipy.ndimage import zoom
            attn_resized = zoom(attn_grid, (img_h / grid_size, img_w / grid_size), order=1)
            
            # Normalize
            attn_resized = (attn_resized - attn_resized.min()) / (attn_resized.max() - attn_resized.min() + 1e-8)
            
            # Overlay on image
            ax.imshow(img_array)
            ax.imshow(attn_resized, alpha=0.5, cmap='jet')
            ax.set_title(f"Latent Token {i + 1}")
            ax.axis('off')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, save_name), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {save_name}")
    
    def plot_latent_progression(
        self,
        attention_output: AttentionOutput,
        save_name: str = "latent_progression.png"
    ):
        """
        Visualize how attention changes across latent tokens (reasoning progression)
        """
        if attention_output.layer_attentions is None:
            print("No attention weights available")
            return
        
        latent_indices = attention_output.latent_token_indices
        image_indices = attention_output.image_token_indices
        
        n_latent = len(latent_indices)
        n_layers = len(attention_output.layer_attentions)
        
        # Create heatmap: layers x latent tokens
        # Value: average attention to image tokens
        progression_matrix = np.zeros((n_layers, n_latent))
        
        for layer_idx in range(n_layers):
            layer_attn = attention_output.layer_attentions[layer_idx][0].mean(dim=0)  # (seq, seq)
            
            for latent_idx, latent_pos in enumerate(latent_indices):
                # Average attention from this latent token to all image tokens
                attn_to_image = layer_attn[latent_pos, image_indices].mean().item()
                progression_matrix[layer_idx, latent_idx] = attn_to_image
        
        # Plot
        fig, ax = plt.subplots(figsize=(8, 10))
        im = ax.imshow(progression_matrix, cmap='viridis', aspect='auto')
        
        ax.set_xlabel("Latent Token")
        ax.set_ylabel("Layer")
        ax.set_xticks(range(n_latent))
        ax.set_xticklabels([f"L{i+1}" for i in range(n_latent)])
        ax.set_yticks(range(n_layers))
        
        ax.set_title("Attention to Image Tokens\nAcross Layers and Latent Tokens")
        plt.colorbar(im, ax=ax, label="Avg Attention")
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, save_name), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {save_name}")


class ProbingExperiment:
    """Linear probing of latent token representations"""
    
    def __init__(self, hidden_dim: int = 2048):
        self.hidden_dim = hidden_dim
        self.probes = {}
    
    def train_probe(
        self,
        hidden_states: List[torch.Tensor],
        labels: List[int],
        probe_name: str = "phishing_classifier"
    ):
        """Train a linear probe on extracted hidden states"""
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import cross_val_score
        
        # Stack hidden states
        X = torch.stack(hidden_states).numpy()
        y = np.array(labels)
        
        # Train probe
        probe = LogisticRegression(max_iter=1000, random_state=42)
        
        # Cross-validation
        scores = cross_val_score(probe, X, y, cv=5)
        
        # Fit final probe
        probe.fit(X, y)
        self.probes[probe_name] = probe
        
        return {
            "mean_accuracy": scores.mean(),
            "std_accuracy": scores.std(),
            "cv_scores": scores.tolist()
        }
    
    def analyze_layer_wise_probing(
        self,
        layer_hidden_states: Dict[str, Dict[str, torch.Tensor]],
        labels: List[int]
    ) -> Dict:
        """
        Probe each layer to see where task-relevant information emerges
        
        Args:
            layer_hidden_states: Dict from extract_hidden_states
            labels: Ground truth labels
        
        Returns:
            Dict with probing accuracy per layer
        """
        results = {}
        
        for layer_name in sorted(layer_hidden_states.keys()):
            # Get hidden states for first latent token (or average all)
            layer_data = layer_hidden_states[layer_name]
            
            # For now, use last latent token
            latent_keys = sorted(layer_data.keys())
            last_latent = latent_keys[-1]
            
            hidden_states = [layer_data[last_latent] for _ in range(len(labels))]
            
            probe_results = self.train_probe(
                hidden_states, labels, probe_name=f"probe_{layer_name}"
            )
            results[layer_name] = probe_results
        
        return results


def main():
    parser = argparse.ArgumentParser(description="Extract and visualize COCONUT attention")
    parser.add_argument("--model_path", type=str, required=True, help="Path to model")
    parser.add_argument("--image_path", type=str, required=True, help="Path to image")
    parser.add_argument("--output_dir", type=str, default="./attention_outputs", help="Output directory")
    parser.add_argument("--prompt", type=str, default="Analyze this webpage screenshot and classify it as benign or malicious.")
    parser.add_argument("--device", type=str, default="cuda")
    
    args = parser.parse_args()
    
    # Initialize extractor
    extractor = AttentionExtractor(
        model_path=args.model_path,
        device=args.device
    )
    
    # Initialize visualizer
    visualizer = AttentionVisualizer(output_dir=args.output_dir)
    
    # Extract attention
    print(f"\nExtracting attention from {args.image_path}...")
    attention_output, generated_text = extractor.extract_attention(
        image_path=args.image_path,
        prompt=args.prompt
    )
    
    print(f"\nGenerated response:\n{generated_text}")
    
    # Visualize
    print("\nGenerating visualizations...")
    image = Image.open(args.image_path).convert("RGB")
    
    # Latent to image attention
    visualizer.plot_latent_to_image_attention(
        attention_output, image,
        save_name="latent_to_image_attention.png"
    )
    
    # Latent progression
    visualizer.plot_latent_progression(
        attention_output,
        save_name="latent_progression.png"
    )
    
    # Save raw attention data
    print(f"\nOutputs saved to {args.output_dir}")


if __name__ == "__main__":
    main()

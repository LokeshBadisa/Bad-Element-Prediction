"""
Comparative Attention Analysis for COCONUT Interpretability Study

Compares attention patterns across:
- COCONUT c2 (2 latent tokens per reasoning step)
- COCONUT c3 (3 latent tokens per reasoning step)  
- COCONUT c4 (4 latent tokens per reasoning step)
- CoT baseline (explicit text reasoning)

For CVPR/ICLR paper: "What Do Latent Tokens Learn for Visual Deception Detection?"
"""

import os
import sys
import json
import torch
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics.pairwise import cosine_similarity
from scipy import stats

# Local imports
from attention_extraction import AttentionExtractor, AttentionVisualizer, ProbingExperiment


@dataclass
class ModelConfig:
    """Configuration for a model variant"""
    name: str
    path: str
    n_latent_tokens: int  # 0 for CoT
    is_coconut: bool = True


@dataclass  
class ComparisonResult:
    """Results from comparing attention patterns"""
    model_name: str
    sample_id: str
    # Attention entropy (how focused vs diffuse)
    attention_entropy: float
    # Attention to specific image regions
    attention_to_logo: float
    attention_to_text: float
    attention_to_form: float
    # Latent token specialization
    latent_specialization_score: float
    # Accuracy
    prediction_correct: bool
    # Hidden state similarity
    cka_similarity: Optional[float] = None


class CKASimilarity:
    """
    Centered Kernel Alignment for comparing representations
    Reference: Kornblith et al., 2019 - "Similarity of Neural Network Representations Revisited"
    """
    
    @staticmethod
    def centering_matrix(n: int) -> np.ndarray:
        """Create centering matrix"""
        return np.eye(n) - np.ones((n, n)) / n
    
    @staticmethod
    def hsic(K: np.ndarray, L: np.ndarray) -> float:
        """Hilbert-Schmidt Independence Criterion"""
        n = K.shape[0]
        H = CKASimilarity.centering_matrix(n)
        return np.trace(K @ H @ L @ H) / ((n - 1) ** 2)
    
    @staticmethod
    def linear_cka(X: np.ndarray, Y: np.ndarray) -> float:
        """
        Compute Linear CKA between two sets of representations
        
        Args:
            X: (n_samples, dim_x) representations from model 1
            Y: (n_samples, dim_y) representations from model 2
            
        Returns:
            CKA similarity score in [0, 1]
        """
        # Compute kernels
        K = X @ X.T
        L = Y @ Y.T
        
        # Compute CKA
        hsic_xy = CKASimilarity.hsic(K, L)
        hsic_xx = CKASimilarity.hsic(K, K)
        hsic_yy = CKASimilarity.hsic(L, L)
        
        return hsic_xy / (np.sqrt(hsic_xx * hsic_yy) + 1e-8)


class ComparativeAnalyzer:
    """Compare attention patterns across model variants"""
    
    def __init__(
        self,
        model_configs: List[ModelConfig],
        output_dir: str = "./comparative_analysis",
        device: str = "cuda"
    ):
        self.model_configs = model_configs
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.device = device
        
        # Load models lazily
        self.extractors: Dict[str, AttentionExtractor] = {}
        
    def _get_extractor(self, model_name: str) -> AttentionExtractor:
        """Lazy load extractor for a model"""
        if model_name not in self.extractors:
            config = next(c for c in self.model_configs if c.name == model_name)
            self.extractors[model_name] = AttentionExtractor(
                model_path=config.path,
                device=self.device
            )
        return self.extractors[model_name]
    
    def compute_attention_entropy(self, attention: torch.Tensor) -> float:
        """
        Compute entropy of attention distribution
        Low entropy = focused attention
        High entropy = diffuse attention
        """
        # Flatten and normalize
        attn = attention.flatten().float()
        attn = attn / (attn.sum() + 1e-8)
        attn = attn[attn > 0]  # Remove zeros for log
        
        # Compute entropy
        entropy = -(attn * torch.log(attn + 1e-8)).sum().item()
        return entropy
    
    def compute_latent_specialization(
        self,
        attention_per_latent: List[torch.Tensor]
    ) -> float:
        """
        Measure how specialized each latent token is
        High score = each token attends to different regions
        Low score = tokens attend to same regions
        """
        if len(attention_per_latent) < 2:
            return 0.0
        
        # Compute pairwise cosine similarity
        similarities = []
        for i in range(len(attention_per_latent)):
            for j in range(i + 1, len(attention_per_latent)):
                sim = cosine_similarity(
                    attention_per_latent[i].cpu().numpy().reshape(1, -1),
                    attention_per_latent[j].cpu().numpy().reshape(1, -1)
                )[0, 0]
                similarities.append(sim)
        
        # Specialization = 1 - average similarity
        return 1.0 - np.mean(similarities)
    
    def analyze_single_sample(
        self,
        model_name: str,
        image_path: str,
        sample_id: str,
        ground_truth: str
    ) -> ComparisonResult:
        """Analyze attention for a single sample"""
        extractor = self._get_extractor(model_name)
        
        # Extract attention
        attention_output, generated_text = extractor.extract_attention(image_path)
        
        # Check prediction correctness (simple heuristic)
        prediction_correct = ground_truth.lower() in generated_text.lower()
        
        # Compute metrics
        if attention_output.layer_attentions is not None:
            # Get last layer attention
            last_layer_attn = attention_output.layer_attentions[-1][0].mean(dim=0)
            
            # Overall entropy
            entropy = self.compute_attention_entropy(last_layer_attn)
            
            # Per-latent attention
            latent_attentions = []
            for idx in attention_output.latent_token_indices:
                attn = last_layer_attn[idx, attention_output.image_token_indices]
                latent_attentions.append(attn)
            
            specialization = self.compute_latent_specialization(latent_attentions)
        else:
            entropy = 0.0
            specialization = 0.0
        
        return ComparisonResult(
            model_name=model_name,
            sample_id=sample_id,
            attention_entropy=entropy,
            attention_to_logo=0.0,  # TODO: Region detection
            attention_to_text=0.0,
            attention_to_form=0.0,
            latent_specialization_score=specialization,
            prediction_correct=prediction_correct
        )
    
    def run_batch_comparison(
        self,
        test_samples: List[Dict],  # [{"image": path, "id": str, "label": str}]
        save_results: bool = True
    ) -> pd.DataFrame:
        """Run comparison across all models and samples"""
        results = []
        
        for config in tqdm(self.model_configs, desc="Models"):
            for sample in tqdm(test_samples, desc=f"Samples ({config.name})", leave=False):
                try:
                    result = self.analyze_single_sample(
                        model_name=config.name,
                        image_path=sample["image"],
                        sample_id=sample["id"],
                        ground_truth=sample["label"]
                    )
                    results.append(result)
                except Exception as e:
                    print(f"Error processing {sample['id']} with {config.name}: {e}")
                    continue
        
        # Convert to DataFrame
        df = pd.DataFrame([vars(r) for r in results])
        
        if save_results:
            df.to_csv(self.output_dir / "comparison_results.csv", index=False)
        
        return df
    
    def compute_cka_between_models(
        self,
        test_samples: List[Dict],
        layer_idx: int = -1
    ) -> Dict[Tuple[str, str], float]:
        """
        Compute CKA similarity between model pairs
        """
        # Collect hidden states per model
        model_hidden_states = defaultdict(list)
        
        for config in tqdm(self.model_configs, desc="Collecting hidden states"):
            extractor = self._get_extractor(config.name)
            
            for sample in test_samples:
                try:
                    hidden_states, latent_indices = extractor.extract_hidden_states(
                        sample["image"]
                    )
                    
                    # Get last layer, last latent token
                    layer_key = f"layer_{layer_idx}" if layer_idx >= 0 else list(hidden_states.keys())[layer_idx]
                    latent_keys = sorted(hidden_states[layer_key].keys())
                    if latent_keys:
                        h = hidden_states[layer_key][latent_keys[-1]]
                        model_hidden_states[config.name].append(h.numpy())
                except Exception as e:
                    print(f"Error: {e}")
                    continue
        
        # Compute pairwise CKA
        cka_results = {}
        model_names = list(model_hidden_states.keys())
        
        for i in range(len(model_names)):
            for j in range(i + 1, len(model_names)):
                name_i, name_j = model_names[i], model_names[j]
                
                # Stack hidden states
                X = np.stack(model_hidden_states[name_i])
                Y = np.stack(model_hidden_states[name_j])
                
                # Ensure same number of samples
                min_n = min(len(X), len(Y))
                X, Y = X[:min_n], Y[:min_n]
                
                cka = CKASimilarity.linear_cka(X, Y)
                cka_results[(name_i, name_j)] = cka
        
        return cka_results
    
    def plot_comparison_summary(self, df: pd.DataFrame):
        """Generate summary plots"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # 1. Accuracy by model
        ax = axes[0, 0]
        acc_by_model = df.groupby("model_name")["prediction_correct"].mean()
        acc_by_model.plot(kind="bar", ax=ax, color="steelblue")
        ax.set_title("Accuracy by Model")
        ax.set_ylabel("Accuracy")
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
        
        # 2. Attention entropy distribution
        ax = axes[0, 1]
        for model in df["model_name"].unique():
            model_df = df[df["model_name"] == model]
            ax.hist(model_df["attention_entropy"], alpha=0.5, label=model, bins=20)
        ax.set_title("Attention Entropy Distribution")
        ax.set_xlabel("Entropy")
        ax.legend()
        
        # 3. Latent specialization
        ax = axes[1, 0]
        spec_by_model = df.groupby("model_name")["latent_specialization_score"].mean()
        spec_by_model.plot(kind="bar", ax=ax, color="coral")
        ax.set_title("Latent Token Specialization")
        ax.set_ylabel("Specialization Score")
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
        
        # 4. Entropy vs Accuracy
        ax = axes[1, 1]
        for model in df["model_name"].unique():
            model_df = df[df["model_name"] == model]
            correct = model_df[model_df["prediction_correct"]]["attention_entropy"]
            incorrect = model_df[~model_df["prediction_correct"]]["attention_entropy"]
            
            ax.scatter(
                [model] * len(correct), correct, 
                c="green", alpha=0.5, label="Correct" if model == df["model_name"].unique()[0] else ""
            )
            ax.scatter(
                [model] * len(incorrect), incorrect,
                c="red", alpha=0.5, label="Incorrect" if model == df["model_name"].unique()[0] else ""
            )
        ax.set_title("Attention Entropy: Correct vs Incorrect")
        ax.set_ylabel("Entropy")
        ax.legend()
        
        plt.tight_layout()
        plt.savefig(self.output_dir / "comparison_summary.png", dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved comparison summary to {self.output_dir / 'comparison_summary.png'}")
    
    def plot_cka_heatmap(self, cka_results: Dict[Tuple[str, str], float]):
        """Plot CKA similarity as heatmap"""
        # Get unique model names
        models = set()
        for (m1, m2) in cka_results.keys():
            models.add(m1)
            models.add(m2)
        models = sorted(models)
        
        # Create similarity matrix
        n = len(models)
        sim_matrix = np.eye(n)  # Diagonal is 1
        
        for i, m1 in enumerate(models):
            for j, m2 in enumerate(models):
                if i != j:
                    key = (m1, m2) if (m1, m2) in cka_results else (m2, m1)
                    if key in cka_results:
                        sim_matrix[i, j] = cka_results[key]
        
        # Plot
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(
            sim_matrix,
            xticklabels=models,
            yticklabels=models,
            annot=True,
            fmt=".3f",
            cmap="YlOrRd",
            ax=ax
        )
        ax.set_title("CKA Similarity Between Models\n(Higher = More Similar Representations)")
        plt.tight_layout()
        plt.savefig(self.output_dir / "cka_heatmap.png", dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved CKA heatmap to {self.output_dir / 'cka_heatmap.png'}")


def create_default_configs(base_path: str) -> List[ModelConfig]:
    """Create default model configurations for DLIS"""
    return [
        ModelConfig(
            name="el_coconut_c2",
            path=f"{base_path}/saves/el_coconut_stage5_c2_merged",
            n_latent_tokens=2
        ),
        ModelConfig(
            name="ablation_c3",
            path=f"{base_path}/saves/coco_s5_c3_merged",
            n_latent_tokens=3
        ),
        ModelConfig(
            name="ablation_c4",
            path=f"{base_path}/saves/coco_s5_c4_merged",
            n_latent_tokens=4
        ),
        ModelConfig(
            name="el_cot",
            path=f"{base_path}/saves/el_cot_merged",
            n_latent_tokens=0,
            is_coconut=False
        ),
    ]


def load_test_samples(test_file: str, image_base_path: str, limit: int = 100) -> List[Dict]:
    """Load test samples from ShareGPT format file"""
    with open(test_file) as f:
        data = json.load(f)
    
    samples = []
    for item in data[:limit]:
        image_path = item["images"][-1]
        # Adjust path if needed
        if not os.path.exists(image_path):
            # Try with base path
            image_path = os.path.join(image_base_path, os.path.basename(image_path))
        
        if os.path.exists(image_path):
            # Extract label from messages
            label_text = item["messages"][-1]["content"]
            label = "malicious" if "malicious" in label_text.lower() else "benign"
            
            samples.append({
                "image": image_path,
                "id": os.path.basename(image_path),
                "label": label
            })
    
    return samples


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Comparative COCONUT Analysis")
    parser.add_argument("--base_path", type=str, default="/data_shubho/local/users/shmallic/ed_fixed/LlamaFactory")
    parser.add_argument("--test_file", type=str, default="testset_sharegpt_data_may23.json")
    parser.add_argument("--image_base", type=str, default="/data_shubho/local/users/shmallic/bep/openphish_crop_images")
    parser.add_argument("--output_dir", type=str, default="./comparative_analysis")
    parser.add_argument("--limit", type=int, default=50, help="Max samples to analyze")
    parser.add_argument("--device", type=str, default="cuda")
    
    args = parser.parse_args()
    
    # Create model configs
    configs = create_default_configs(args.base_path)
    
    # Initialize analyzer
    analyzer = ComparativeAnalyzer(
        model_configs=configs,
        output_dir=args.output_dir,
        device=args.device
    )
    
    # Load test samples
    test_samples = load_test_samples(
        args.test_file,
        args.image_base,
        limit=args.limit
    )
    print(f"Loaded {len(test_samples)} test samples")
    
    # Run batch comparison
    print("\n=== Running Batch Comparison ===")
    df = analyzer.run_batch_comparison(test_samples)
    
    # Generate plots
    print("\n=== Generating Plots ===")
    analyzer.plot_comparison_summary(df)
    
    # Compute CKA
    print("\n=== Computing CKA Similarity ===")
    cka_results = analyzer.compute_cka_between_models(test_samples[:20])  # Limit for speed
    analyzer.plot_cka_heatmap(cka_results)
    
    # Summary statistics
    print("\n=== Summary Statistics ===")
    for model in df["model_name"].unique():
        model_df = df[df["model_name"] == model]
        print(f"\n{model}:")
        print(f"  Accuracy: {model_df['prediction_correct'].mean():.3f}")
        print(f"  Avg Entropy: {model_df['attention_entropy'].mean():.3f}")
        print(f"  Avg Specialization: {model_df['latent_specialization_score'].mean():.3f}")
    
    print(f"\nResults saved to {args.output_dir}")


if __name__ == "__main__":
    main()

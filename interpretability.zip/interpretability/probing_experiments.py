"""
Linear Probing for COCONUT Latent Token Representations

Trains linear probes to predict:
1. Phishing vs Benign (main task)
2. Targeted brand (Google, Microsoft, Apple, etc.)
3. Attack type (credential theft, malware download, etc.)
4. Visual deception indicators (fake form, fake logo, etc.)

This reveals what semantic information is encoded at each latent token position
and at which layers this information emerges.
"""

import os
import sys
import json
import torch
import numpy as np
from pathlib import Path
from tqdm import tqdm
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.decomposition import PCA

# Local imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from attention_extraction import AttentionExtractor


@dataclass
class ProbingTask:
    """Configuration for a probing task"""
    name: str
    labels: List[str]  # Possible label values
    description: str


# Define probing tasks
PROBING_TASKS = {
    "phishing": ProbingTask(
        name="phishing",
        labels=["benign", "malicious"],
        description="Detect phishing vs benign"
    ),
    "brand": ProbingTask(
        name="brand",
        labels=["google", "microsoft", "apple", "facebook", "amazon", "paypal", "netflix", "other"],
        description="Identify targeted brand"
    ),
    "attack_type": ProbingTask(
        name="attack_type",
        labels=["credential_theft", "malware", "scam", "unknown"],
        description="Classify attack type"
    ),
    "deception_indicators": ProbingTask(
        name="deception_indicators",
        labels=["fake_login", "urgency_text", "mismatched_branding", "suspicious_url"],
        description="Identify visual deception cues (multi-label)"
    )
}


class HiddenStateExtractor:
    """Extract hidden states from multiple layers and latent positions"""
    
    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        layers_to_extract: List[int] = None
    ):
        self.extractor = AttentionExtractor(model_path, device=device)
        self.layers_to_extract = layers_to_extract  # None = all layers
        
    def extract_from_sample(
        self,
        image_path: str,
        prompt: str = "Analyze this webpage screenshot."
    ) -> Dict[str, torch.Tensor]:
        """
        Extract hidden states from all layers and latent positions
        
        Returns:
            Dict mapping "layer_{L}_latent_{T}" -> hidden_state tensor
        """
        hidden_states, latent_indices = self.extractor.extract_hidden_states(
            image_path, prompt
        )
        
        result = {}
        for layer_key, layer_dict in hidden_states.items():
            if self.layers_to_extract is not None:
                layer_idx = int(layer_key.split("_")[1])
                if layer_idx not in self.layers_to_extract:
                    continue
            
            for latent_key, tensor in layer_dict.items():
                result[f"{layer_key}_{latent_key}"] = tensor
        
        return result


class ProbingDataset:
    """Dataset for probing experiments"""
    
    def __init__(
        self,
        samples: List[Dict],  # [{"image": path, "phishing": label, "brand": label, ...}]
        model_path: str,
        device: str = "cuda",
        cache_dir: str = "./probing_cache"
    ):
        self.samples = samples
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.extractor = HiddenStateExtractor(model_path, device)
        
        # Cache for hidden states
        self.hidden_states_cache = {}
        
    def extract_all(self, use_cache: bool = True) -> Dict[str, np.ndarray]:
        """
        Extract hidden states for all samples
        
        Returns:
            Dict mapping position_key -> (n_samples, hidden_dim) array
        """
        cache_file = self.cache_dir / "hidden_states.npz"
        
        if use_cache and cache_file.exists():
            print("Loading cached hidden states...")
            data = np.load(cache_file)
            return {key: data[key] for key in data.files}
        
        print("Extracting hidden states...")
        all_states = defaultdict(list)
        
        for sample in tqdm(self.samples):
            try:
                states = self.extractor.extract_from_sample(sample["image"])
                for key, tensor in states.items():
                    all_states[key].append(tensor.numpy())
            except Exception as e:
                print(f"Error extracting {sample['image']}: {e}")
                # Add zeros as placeholder
                for key in all_states.keys():
                    if len(all_states[key]) < len(self.samples):
                        all_states[key].append(np.zeros_like(all_states[key][-1]))
        
        # Stack into arrays
        result = {key: np.stack(tensors) for key, tensors in all_states.items()}
        
        # Cache
        np.savez(cache_file, **result)
        print(f"Cached hidden states to {cache_file}")
        
        return result
    
    def get_labels(self, task_name: str) -> np.ndarray:
        """Get labels for a specific task"""
        labels = []
        for sample in self.samples:
            if task_name in sample:
                labels.append(sample[task_name])
            else:
                labels.append("unknown")
        return np.array(labels)


class LinearProbe:
    """Train and evaluate linear probes"""
    
    def __init__(self, task: ProbingTask, regularization: str = "l2"):
        self.task = task
        self.regularization = regularization
        self.label_encoder = LabelEncoder()
        self.scaler = StandardScaler()
        
    def train_and_evaluate(
        self,
        X: np.ndarray,
        y: np.ndarray,
        n_folds: int = 5
    ) -> Dict:
        """
        Train probe with cross-validation
        
        Returns:
            Dict with accuracy, per-class F1, etc.
        """
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        
        # Handle class imbalance
        unique, counts = np.unique(y_encoded, return_counts=True)
        if len(unique) < 2:
            return {"accuracy": 0.0, "error": "Only one class present"}
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train probe
        if self.regularization == "l2":
            probe = LogisticRegression(
                max_iter=1000,
                class_weight="balanced",
                random_state=42,
                solver="lbfgs"
            )
        else:
            probe = RidgeClassifier(class_weight="balanced", random_state=42)
        
        # Cross-validation
        cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
        
        # Check if enough samples for CV
        min_class_count = min(counts)
        if min_class_count < n_folds:
            n_folds = max(2, min_class_count)
            cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
        
        scores = cross_val_score(probe, X_scaled, y_encoded, cv=cv, scoring="accuracy")
        
        # Fit final model
        probe.fit(X_scaled, y_encoded)
        y_pred = probe.predict(X_scaled)
        
        return {
            "accuracy": scores.mean(),
            "accuracy_std": scores.std(),
            "cv_scores": scores.tolist(),
            "n_classes": len(unique),
            "classes": self.label_encoder.classes_.tolist(),
            "classification_report": classification_report(
                y_encoded, y_pred, 
                target_names=self.label_encoder.classes_,
                output_dict=True
            )
        }


class ProbingExperimentRunner:
    """Run systematic probing experiments"""
    
    def __init__(
        self,
        dataset: ProbingDataset,
        output_dir: str = "./probing_results"
    ):
        self.dataset = dataset
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def run_layer_wise_probing(
        self,
        task_name: str,
        aggregate_latents: str = "last"  # "last", "mean", "concat"
    ) -> Dict[int, Dict]:
        """
        Probe each layer to see where task information emerges
        
        Args:
            task_name: Which task to probe for
            aggregate_latents: How to aggregate across latent tokens
            
        Returns:
            Dict mapping layer_idx -> probe results
        """
        task = PROBING_TASKS[task_name]
        labels = self.dataset.get_labels(task_name)
        
        # Extract hidden states
        hidden_states = self.dataset.extract_all()
        
        # Group by layer
        layer_to_positions = defaultdict(list)
        for key in hidden_states.keys():
            parts = key.split("_")
            layer_idx = int(parts[1])
            layer_to_positions[layer_idx].append(key)
        
        results = {}
        print(f"\nProbing for {task_name}...")
        
        for layer_idx in tqdm(sorted(layer_to_positions.keys())):
            positions = layer_to_positions[layer_idx]
            
            # Aggregate latent token representations
            if aggregate_latents == "last":
                # Use last latent token
                key = sorted(positions)[-1]
                X = hidden_states[key]
            elif aggregate_latents == "mean":
                # Mean across latent tokens
                X = np.mean([hidden_states[k] for k in positions], axis=0)
            elif aggregate_latents == "concat":
                # Concatenate all latent tokens
                X = np.concatenate([hidden_states[k] for k in sorted(positions)], axis=1)
            else:
                raise ValueError(f"Unknown aggregation: {aggregate_latents}")
            
            # Train probe
            probe = LinearProbe(task)
            results[layer_idx] = probe.train_and_evaluate(X, labels)
        
        return results
    
    def run_position_wise_probing(self, task_name: str) -> Dict[str, Dict]:
        """
        Probe each latent token position separately
        
        Returns:
            Dict mapping "layer_L_latent_T" -> probe results
        """
        task = PROBING_TASKS[task_name]
        labels = self.dataset.get_labels(task_name)
        hidden_states = self.dataset.extract_all()
        
        results = {}
        print(f"\nProbing positions for {task_name}...")
        
        for key in tqdm(sorted(hidden_states.keys())):
            X = hidden_states[key]
            probe = LinearProbe(task)
            results[key] = probe.train_and_evaluate(X, labels)
        
        return results
    
    def plot_layer_accuracy(
        self,
        layer_results: Dict[int, Dict],
        task_name: str,
        save_name: str = None
    ):
        """Plot accuracy across layers"""
        layers = sorted(layer_results.keys())
        accuracies = [layer_results[l]["accuracy"] for l in layers]
        stds = [layer_results[l].get("accuracy_std", 0) for l in layers]
        
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(layers, accuracies, marker='o', linewidth=2, markersize=6)
        ax.fill_between(
            layers,
            np.array(accuracies) - np.array(stds),
            np.array(accuracies) + np.array(stds),
            alpha=0.3
        )
        
        ax.set_xlabel("Layer")
        ax.set_ylabel("Probing Accuracy")
        ax.set_title(f"Layer-wise Probing: {task_name}")
        ax.grid(True, alpha=0.3)
        
        # Add horizontal line for random baseline
        n_classes = layer_results[layers[0]].get("n_classes", 2)
        ax.axhline(y=1.0/n_classes, color='r', linestyle='--', label=f'Random ({1.0/n_classes:.2f})')
        ax.legend()
        
        plt.tight_layout()
        
        save_path = save_name or f"layer_probing_{task_name}.png"
        plt.savefig(self.output_dir / save_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved {save_path}")
    
    def plot_position_heatmap(
        self,
        position_results: Dict[str, Dict],
        task_name: str,
        save_name: str = None
    ):
        """Plot probing accuracy as layer x latent position heatmap"""
        # Parse keys to get layer and latent indices
        layers = set()
        latents = set()
        for key in position_results.keys():
            parts = key.split("_")
            layers.add(int(parts[1]))
            latents.add(int(parts[3]))
        
        layers = sorted(layers)
        latents = sorted(latents)
        
        # Create matrix
        matrix = np.zeros((len(layers), len(latents)))
        for key, result in position_results.items():
            parts = key.split("_")
            l_idx = layers.index(int(parts[1]))
            t_idx = latents.index(int(parts[3]))
            matrix[l_idx, t_idx] = result["accuracy"]
        
        # Plot
        fig, ax = plt.subplots(figsize=(8, 10))
        sns.heatmap(
            matrix,
            xticklabels=[f"L{i}" for i in latents],
            yticklabels=[f"{l}" for l in layers],
            cmap="YlOrRd",
            annot=False,
            ax=ax
        )
        ax.set_xlabel("Latent Token Position")
        ax.set_ylabel("Layer")
        ax.set_title(f"Probing Accuracy: {task_name}")
        
        plt.tight_layout()
        
        save_path = save_name or f"position_heatmap_{task_name}.png"
        plt.savefig(self.output_dir / save_path, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved {save_path}")
    
    def run_full_analysis(self, tasks: List[str] = None):
        """Run complete probing analysis"""
        if tasks is None:
            tasks = ["phishing"]  # Start with main task
        
        all_results = {}
        
        for task_name in tasks:
            print(f"\n{'='*50}")
            print(f"Task: {task_name}")
            print(f"{'='*50}")
            
            # Layer-wise probing
            layer_results = self.run_layer_wise_probing(task_name)
            self.plot_layer_accuracy(layer_results, task_name)
            
            # Position-wise probing
            position_results = self.run_position_wise_probing(task_name)
            self.plot_position_heatmap(position_results, task_name)
            
            all_results[task_name] = {
                "layer_wise": layer_results,
                "position_wise": position_results
            }
        
        # Save results
        results_file = self.output_dir / "probing_results.json"
        with open(results_file, "w") as f:
            # Convert numpy types for JSON
            def convert(obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                if isinstance(obj, np.floating):
                    return float(obj)
                if isinstance(obj, np.integer):
                    return int(obj)
                if isinstance(obj, dict):
                    return {k: convert(v) for k, v in obj.items()}
                if isinstance(obj, list):
                    return [convert(i) for i in obj]
                return obj
            
            json.dump(convert(all_results), f, indent=2)
        
        print(f"\nResults saved to {results_file}")
        return all_results


def create_sample_dataset(
    test_file: str,
    image_base: str,
    limit: int = 200
) -> List[Dict]:
    """Create probing dataset from test file"""
    with open(test_file) as f:
        data = json.load(f)
    
    samples = []
    for item in data[:limit]:
        image_path = item["images"][-1]
        
        # Fix path if needed
        if not os.path.exists(image_path):
            image_path = os.path.join(image_base, os.path.basename(image_path))
        
        if not os.path.exists(image_path):
            continue
        
        # Parse label
        label_text = item["messages"][-1]["content"]
        phishing_label = "malicious" if "malicious" in label_text.lower() else "benign"
        
        # TODO: Extract brand and attack type from data
        samples.append({
            "image": image_path,
            "phishing": phishing_label
        })
    
    return samples


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="COCONUT Linear Probing")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--test_file", type=str, required=True)
    parser.add_argument("--image_base", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="./probing_results")
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--device", type=str, default="cuda")
    
    args = parser.parse_args()
    
    # Create dataset
    samples = create_sample_dataset(args.test_file, args.image_base, args.limit)
    print(f"Created dataset with {len(samples)} samples")
    
    dataset = ProbingDataset(
        samples=samples,
        model_path=args.model_path,
        device=args.device,
        cache_dir=os.path.join(args.output_dir, "cache")
    )
    
    # Run experiments
    runner = ProbingExperimentRunner(dataset, args.output_dir)
    results = runner.run_full_analysis(tasks=["phishing"])
    
    print("\n=== Summary ===")
    for task_name, task_results in results.items():
        layer_results = task_results["layer_wise"]
        best_layer = max(layer_results.keys(), key=lambda l: layer_results[l]["accuracy"])
        print(f"\n{task_name}:")
        print(f"  Best layer: {best_layer} (acc={layer_results[best_layer]['accuracy']:.3f})")


if __name__ == "__main__":
    main()
